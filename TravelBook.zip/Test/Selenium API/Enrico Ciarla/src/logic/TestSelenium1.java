package logic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestSelenium1 {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/TravelBookWeb/index.jsp");
		
		driver.findElement(By.xpath("//*[@id=\"navbarColor01\"]/form/input[1]")).sendKeys("roma");
		driver.findElement(By.xpath("//*[@id=\"startdate\"]")).sendKeys("11/02/2020");
		driver.findElement(By.xpath("//*[@id=\"enddate\"]")).sendKeys("18/02/2020");
		driver.findElement(By.xpath("//*[@id=\"navbarColor01\"]/form/div/input")).sendKeys("2");
		driver.findElement(By.xpath("//*[@id=\"navbarColor01\"]/form/button")).click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement txtBoxContent = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/h1"));
		
		System.out.println("Printing the name of the first hotel of the list: " + txtBoxContent.getText());
		
		driver.close();
		
	}

}
